from django.apps import AppConfig


class DjangoUrlShortenerConfig(AppConfig):
    name = 'django_url_shortener'
